import cv2
#import cv2.highgui as highgui
from cv2 import *
cam_port = 0
cam = cv2.VideoCapture(cam_port)
inp = input('Enter person name')
while(1): 
        result,image = cam.read()
        imshow(inp, image)
        if cv2.waitKey(0):
         imwrite(inp+".png", image)
         print("image taken")
else:
	print("No image detected. Please! try again")
